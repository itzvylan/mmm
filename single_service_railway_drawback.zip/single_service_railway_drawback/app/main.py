from pathlib import Path
from fastapi import FastAPI, Depends, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from sqlalchemy.orm import Session
from .db import Base, engine, SessionLocal
from .models import Lead
from .schemas import LeadCreate, LeadOut
from .seed import seed_if_empty

app = FastAPI(title="Drawback Recovery Pipeline")

Base.metadata.create_all(bind=engine)

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@app.get("/health")
def health():
    return {"ok": True}

@app.get("/api/leads", response_model=list[LeadOut])
def list_leads(db: Session = Depends(get_db)):
    return db.query(Lead).order_by(Lead.id.desc()).all()

@app.post("/api/leads", response_model=LeadOut)
def create_lead(payload: LeadCreate, db: Session = Depends(get_db)):
    lead = Lead(**payload.model_dump(), status="new")
    db.add(lead)
    db.commit()
    db.refresh(lead)
    return lead

@app.post("/api/leads/{lead_id}/queue", response_model=LeadOut)
def queue_lead(lead_id: int, db: Session = Depends(get_db)):
    lead = db.get(Lead, lead_id)
    if not lead:
        raise HTTPException(status_code=404, detail="Lead not found")
    lead.status = "queued"
    db.commit()
    db.refresh(lead)
    return lead

@app.post("/api/seed")
def seed(db: Session = Depends(get_db)):
    created = seed_if_empty(db)
    return {"created": created}

# Frontend build paths
BASE_DIR = Path(__file__).resolve().parent.parent
DIST_DIR = BASE_DIR / "frontend_dist"
ASSETS_DIR = DIST_DIR / "assets"

if ASSETS_DIR.exists():
    app.mount("/assets", StaticFiles(directory=ASSETS_DIR), name="assets")

favicon = DIST_DIR / "favicon.ico"
if favicon.exists():
    @app.get("/favicon.ico", include_in_schema=False)
    def favicon_file():
        return FileResponse(favicon)

@app.get("/{full_path:path}", include_in_schema=False)
def serve_spa(full_path: str):
    index_file = DIST_DIR / "index.html"
    if index_file.exists():
        return FileResponse(index_file)
    return {
        "message": "Frontend not built yet. Build the frontend or deploy with Docker.",
        "path": full_path
    }
