import { useEffect, useState } from 'react'

const emptyLead = {
  company_name: '',
  website: '',
  contact_email: '',
  industry: '',
  estimated_refund: 0,
}

export default function App() {
  const [leads, setLeads] = useState([])
  const [form, setForm] = useState(emptyLead)
  const [loading, setLoading] = useState(false)
  const [message, setMessage] = useState('')

  const loadLeads = async () => {
    const res = await fetch('/api/leads')
    const data = await res.json()
    setLeads(data)
  }

  useEffect(() => {
    loadLeads()
  }, [])

  const seed = async () => {
    setLoading(true)
    setMessage('')
    const res = await fetch('/api/seed', { method: 'POST' })
    const data = await res.json()
    setMessage(`Loaded ${data.created} sample lead(s).`)
    await loadLeads()
    setLoading(false)
  }

  const createLead = async (e) => {
    e.preventDefault()
    setLoading(true)
    setMessage('')
    await fetch('/api/leads', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        ...form,
        estimated_refund: Number(form.estimated_refund || 0),
      }),
    })
    setForm(emptyLead)
    setMessage('Lead added.')
    await loadLeads()
    setLoading(false)
  }

  const queueLead = async (id) => {
    setLoading(true)
    setMessage('')
    await fetch(`/api/leads/${id}/queue`, { method: 'POST' })
    setMessage('Lead queued for outreach.')
    await loadLeads()
    setLoading(false)
  }

  return (
    <div className="page">
      <header className="hero">
        <div>
          <p className="eyebrow">Single-Service Railway Starter</p>
          <h1>Drawback Recovery Pipeline</h1>
          <p className="sub">
            One website. One backend. One database. No split-hosting headache.
          </p>
        </div>
        <button onClick={seed} disabled={loading}>Load sample leads</button>
      </header>

      <section className="grid">
        <form className="card" onSubmit={createLead}>
          <h2>Add a lead</h2>
          <label>Company name
            <input value={form.company_name} onChange={(e) => setForm({ ...form, company_name: e.target.value })} required />
          </label>
          <label>Website
            <input value={form.website} onChange={(e) => setForm({ ...form, website: e.target.value })} />
          </label>
          <label>Email
            <input value={form.contact_email} onChange={(e) => setForm({ ...form, contact_email: e.target.value })} />
          </label>
          <label>Industry
            <input value={form.industry} onChange={(e) => setForm({ ...form, industry: e.target.value })} />
          </label>
          <label>Estimated refund
            <input type="number" value={form.estimated_refund} onChange={(e) => setForm({ ...form, estimated_refund: e.target.value })} />
          </label>
          <button type="submit" disabled={loading}>Save lead</button>
          {message && <p className="message">{message}</p>}
        </form>

        <div className="card">
          <h2>Leads</h2>
          <div className="lead-list">
            {leads.length === 0 ? (
              <p>No leads yet. Press “Load sample leads” or add one.</p>
            ) : (
              leads.map((lead) => (
                <div className="lead" key={lead.id}>
                  <div>
                    <strong>{lead.company_name}</strong>
                    <p>{lead.industry || 'No industry'} • ${lead.estimated_refund.toLocaleString()}</p>
                    <p>{lead.contact_email || 'No email yet'}</p>
                  </div>
                  <div className="lead-right">
                    <span className={`badge ${lead.status}`}>{lead.status}</span>
                    <button disabled={loading || lead.status === 'queued'} onClick={() => queueLead(lead.id)}>
                      Queue
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </section>
    </div>
  )
}
